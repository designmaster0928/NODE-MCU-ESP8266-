-- wifi setup
station_cfg={}
station_cfg.ssid= "ssid"     -- Enter SSID here
station_cfg.pwd	= "password"  --Enter password here

timer_id        = 1
potreading      = 0     -- set initial pot reading to 0
LEDbrightness   = 0     -- Set initial LED brightness
LEDpin          = 6     -- Declare LED pin no.
PWMDutyCycle    = 512   -- Set PWM duty cycle in between 0-1023
PWMfrequency    = 1000  -- Set PWM frequency

-- adafruit server details
server          = "io.adafruit.com"
port            = 1883
publish_topic   = "/publish_topic" -- e.g. "Nivya151/feeds/potValue"
subscribe_topic = "/subscribe_topic" -- e.g. "Nivya151/feeds/ledBrightness"
aio_username    = "aio_username" -- e.g. "Nivya151"
aio_key         = "aio_key"
client_id       = "1"



wifi.setmode(wifi.STATION)  -- set wi-fi mode to station
wifi.sta.config(station_cfg)-- set ssid&pwd to config
wifi.sta.connect()          -- connect to router


pwm.setup(LEDpin, PWMfrequency, PWMDutyCycle)-- Setup PWM
pwm.start(LEDpin)   -- Start PWM on LED pin

-- init mqtt client with logins, keepalive timer 120s
mqttClient = mqtt.Client(client_id, 120, aio_username, aio_key)
-- setup Last Will and Testament (optional)
-- Broker will publish a message with qos = 0, retain = 0, data = "offline" 
-- to topic "/lwt" if client don't send keepalive packet
mqttClient:lwt("/lwt", "offline", 0, 0)

mqttClient:on("connect", function(client) print ("client connected") end)
mqttClient:on("offline", function(client) print ("client offline") end)

-- on message receive event
mqttClient:on("message", function(client, topic, data) 
--  print(topic .. ":" ) 
  if data ~= nil then
    print("received : ", data)
    LEDbrightness = tonumber(data)
    if LEDbrightness > 1023 then-- Limit LED brightness to max of duty cycle
        LEDbrightness = 1023
    end
    pwm.setduty(LEDpin, LEDbrightness)-- set PWM duty cycle to LED brightness
  end
end)

function subscribe(mq_client)
    mq_client:connect(server, port, 0, 0,
    function(client)
        print("connected")
        -- subscribe topic with qos = 0
        client:subscribe(subscribe_topic, 0, function(client) print("subscribe success") end)
        -- set auto (contineous) alarm of 500ms to send pot value on alarm.
        tmr.alarm(timer_id, 500, tmr.ALARM_AUTO, function() publish(mqttClient) end)
    end,
    function(client, reason)
      print("failed reason: " .. reason)
    end)
end

function publish(mq_client)
    adcvalue = adc.read(0)
    -- since adc readings not stable even pot is in steady position we need to add threshold
    -- add threshold of +- 10 in potreading to avoid continuous publish 
    if adcvalue > potreading+10 or adcvalue < potreading-10 then
        potreading = adcvalue
        -- publish a message with pot data, QoS = 0, retain = 0
        mq_client:publish(publish_topic, potreading, 0, 0, function(client) print("sent : ",adcvalue) end)
    end
    
end

subscribe(mqttClient)
