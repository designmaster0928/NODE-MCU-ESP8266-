print("ADC value:", adc.read(0)) -- print external voltage
