pin = 1

status, temp, humi, temp_dec, humi_dec = dht.read(pin)--read dht11 from pin

if status == dht.OK then    --check status is ok and print temperature and humidity
    print(string.format("DHT Temperature:%d.%03d;Humidity:%d.%03d",
          math.floor(temp),
          temp_dec,
          math.floor(humi),
          humi_dec
    ))
elseif status == dht.ERROR_CHECKSUM then    --else print either status
    print( "DHT Checksum error." )
elseif status == dht.ERROR_TIMEOUT then
    print( "DHT timed out." )
end