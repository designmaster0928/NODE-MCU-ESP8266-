Vref = 3.3
resolution = Vref/1023

analogVtg = adc.read(0)
if analogVtg > 1023 then
        analogVtg = 1023
end
temperature = (analogVtg * resolution)*100
print('LM35 Temperature:', temperature)

