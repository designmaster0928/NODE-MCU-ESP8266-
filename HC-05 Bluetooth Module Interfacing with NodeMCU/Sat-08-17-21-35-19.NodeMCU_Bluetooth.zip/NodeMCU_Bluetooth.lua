LEDpin = 4

gpio.mode(LEDpin, gpio.OUTPUT)--set LED pin as output pin
gpio.write(LEDpin, gpio.LOW)-- set LED state initially low

--begin uart with specs
uart.setup(0, 9600, 8, uart.PARITY_NONE, uart.STOPBITS_1, 1)
--set callback function on receive to make decision about LED on/off
uart.on("data",1,
function(data)
    if(data == "1") then
        gpio.write(LEDpin, gpio.HIGH)
        print("LED ON")
    elseif(data == "2") then
        gpio.write(LEDpin, gpio.LOW)
        print("LED OFF")
    else
        print("select proper option") 
    end
end, 0)