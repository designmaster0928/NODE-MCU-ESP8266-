count = 0

-- set uart0 with 1200 baud rate, 8 databits, no pariy, 1 stop bit with echo
uart.setup(0,1200,8,0,1,1)

while true do   -- continuous send count
    print(count)
    count = count + 1
    tmr.delay(1000000)
end