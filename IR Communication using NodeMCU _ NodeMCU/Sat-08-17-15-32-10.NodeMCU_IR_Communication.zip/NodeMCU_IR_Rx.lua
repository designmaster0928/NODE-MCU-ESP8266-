-- set uart0 with 1200 baud rate, 8 databits, no pariy, 1 stop bit with echo
uart.setup(0,1200,8,0,1,1)
--print received data
uart.on("data", "\n", function(data) print("receive from uart:", data) end, 0)
