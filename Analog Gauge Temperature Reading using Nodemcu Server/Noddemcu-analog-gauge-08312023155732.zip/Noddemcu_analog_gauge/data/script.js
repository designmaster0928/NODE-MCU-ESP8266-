window.addEventListener('load', getReadings);

var gaugeTemp = new RadialGauge({
 renderTo: 'gauge-temperature',
  width: 300,
  height: 300,
  units: "Temperature (DegC)",
  minValue: 0,
  maxValue: 100,
  colorValueBoxRect: "#ff0000",
  colorValueBoxRectEnd: "#ff0000",
  colorValueBoxBackground: "#ffffff",
  valueInt: 2,
  majorTicks: [
      "0",
	  "10",
      "20",
	  "30",
      "40",
	  "50",
      "60",
	  "70",
      "80",
	  "90",
      "100"

  ],
  minorTicks: 4,
  strokeTicks: true,
  highlights: [
      {
          "from": 60,
          "to": 100,
          "color": "#ff0000"
      }
  ],
  colorPlate: "#ababab",
  borderShadowWidth: 0,
  borders: true,
  needleType: "line",
  colorNeedle: "#ff0000",
  colorNeedleEnd: "#ff0000",
  needleWidth: 1,
  needleCircleSize: 4,
  colorNeedleCircleOuter: "#ff0000",
  needleCircleOuter: true,
  needleCircleInner: false,
  animationDuration: 1500,
  animationRule: "linear"
}).draw();


function getReadings(){
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var myObj = JSON.parse(this.responseText);
      console.log(myObj);
      var temp = myObj.temperature;
      gaugeTemp.value = temp;
    }
  }; 
  xhr.open("GET", "/readings", true);
  xhr.send();
}

if (!!window.EventSource) {
  var source = new EventSource('/events');
  
  source.addEventListener('open', function(e) {
    console.log("Events Connected");
  }, false);

  source.addEventListener('error', function(e) {
    if (e.target.readyState != EventSource.OPEN) {
      console.log("Events Disconnected");
    }
  }, false);
  
  source.addEventListener('message', function(e) {
    console.log("message", e.data);
  }, false);
  
  source.addEventListener('new_readings', function(e) {
    console.log("new_readings", e.data);
    var myObj = JSON.parse(e.data);
    console.log(myObj);
    gaugeTemp.value = myObj.temperature;
  }, false);
}