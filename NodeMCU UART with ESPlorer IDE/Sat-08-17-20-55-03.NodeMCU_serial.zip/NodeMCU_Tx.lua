uart.setup(1, 115200, 8, uart.PARITY_NONE, uart.STOPBITS_1, 1)-- setup UART1 i.e. pin GPIO2
while true do   --send string per second continuously
    uart.write(1, "Hello friend\n")
    tmr.delay(1000000)
end