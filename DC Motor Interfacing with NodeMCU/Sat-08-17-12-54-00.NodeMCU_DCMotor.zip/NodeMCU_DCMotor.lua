PWM_Pin = 5        --set pins for control
DirectionPin1 = 6
DirectionPin2 = 7
DirectionControlPin = 8

timer_id = 1
delay_ms = 200

PWMfrequency = 1000 -- Set PWM frequency
PWMDutyCycle = 512  -- Set PWM duty cycle in between 0-1023

pwm.setup(PWM_Pin, PWMfrequency, PWMDutyCycle)-- Setup PWM
pwm.start(PWM_Pin)   -- Start PWM on PWM pin

gpio.mode(DirectionPin1,gpio.OUTPUT)--set direction control pins as output pins
gpio.mode(DirectionPin2,gpio.OUTPUT)
gpio.mode(DirectionControlPin,gpio.INT,gpio.PULLUP)-- Set GPIO interrupt mode for pin 

DirectionPinValue1 = gpio.LOW   -- write direction control pin initial states
DirectionPinValue2 = gpio.HIGH
gpio.write(DirectionPin1,DirectionPinValue1)
gpio.write(DirectionPin2,DirectionPinValue2)

function interrupt(level, stamp)-- callback function while interrupt
    gpio.trig(DirectionControlPin) -- disable interrupt for that pin

    if (DirectionPinValue1 == gpio.HIGH) then
        DirectionPinValue1 = gpio.LOW
        gpio.write(DirectionPin1,DirectionPinValue1)
    else
        DirectionPinValue1 = gpio.HIGH
        gpio.write(DirectionPin1,DirectionPinValue1)
    end
    if (DirectionPinValue2 == gpio.HIGH) then
        DirectionPinValue2 = gpio.LOW
        gpio.write(DirectionPin2,DirectionPinValue2)
    else
        DirectionPinValue2 = gpio.HIGH
        gpio.write(DirectionPin2,DirectionPinValue2)
    end

    tmr.delay(700000)    -- wait 700 ms
    print('Rotational Direction changed..!')--print direction change msg

    gpio.trig(DirectionControlPin,"high",interrupt)--re-enable interrupt on pin while exit
end

gpio.trig(DirectionControlPin,"high",interrupt)-- set interrupt type high i.e. High level

function POT_Control()
    POT_read = adc.read(0) -- Read pot using ADC
    if POT_read > 1023 then-- Limit PWM to max of duty cycle
        POT_read = 1023
    end
    pwm.setduty(PWM_Pin, POT_read)-- set PWM duty cycle to DC motor
    print('Speed (%):',math.floor(100*POT_read/1023))-- print speed of DC motor
end
tmr.alarm(timer_id,delay_ms,tmr.ALARM_AUTO,function() POT_Control() end)--start alarm function to PWM duty cycle control
