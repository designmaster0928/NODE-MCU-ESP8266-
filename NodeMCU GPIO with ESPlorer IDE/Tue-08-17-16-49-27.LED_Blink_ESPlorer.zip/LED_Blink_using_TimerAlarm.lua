LEDpin = 4
timer_id = 1
delay_ms = 500

gpio.mode(LEDpin,gpio.OUTPUT)  -- Make LED pin 4 (D4 on kit) as output
LEDvalue = gpio.LOW            -- Initialize variable LEDvalue with digital LOW
-- Set timer alarm calls LEDBlink() function after every 1 sec
tmr.alarm(timer_id,delay_ms,tmr.ALARM_AUTO,function() LEDBlink() end)

function LEDBlink()
    if LEDvalue == gpio.LOW then -- This part inverts the variable state
        LEDvalue = gpio.HIGH
    else
        LEDvalue = gpio.LOW
    end
    gpio.write(LEDpin,LEDvalue) --write to the LEDpin
end
