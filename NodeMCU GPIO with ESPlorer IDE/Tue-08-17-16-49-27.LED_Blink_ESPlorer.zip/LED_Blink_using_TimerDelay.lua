LEDpin = 4         -- Declare LED pin no.
delayuS = 500000   -- Set delay in microSecond. here 0.5 second

gpio.mode(LEDpin,gpio.OUTPUT)-- Set LED pin as GPIO output pin
while(1)           -- Define infinite while loop
do
gpio.write(LEDpin,gpio.HIGH)-- Set LED pin HIGH i.e. LED ON
tmr.delay(delayuS) -- timer Delay
gpio.write(LEDpin,gpio.LOW)-- Set LED pin LOW i.e. LED OFF
tmr.delay(delayuS) -- timer Delay
end
