ServoControlPin = 2
PWMfrequency = 50 -- Set PWM frequency
PWMDutyCycle = 512  -- Set PWM duty cycle in between 0-1023

pwm.setup(ServoControlPin, PWMfrequency, PWMDutyCycle)-- Setup PWM
pwm.start(ServoControlPin)   -- Start PWM on control pin

while true do
    POT_read = adc.read(0) -- Read pot using ADC
    if POT_read > 1023 then-- Limit PWM to max of duty cycle
        POT_read = 1023
    end
    POT_read = 25+((85*POT_read/1023))--make it in range 20 to 110
    --we got practical range in 0.5% to 2.15% of 50Hz PWM
    pwm.setduty(ServoControlPin, POT_read)-- set PWM duty cycle
    tmr.delay(10000)
end