station_cfg={}
station_cfg.ssid="ssid"  -- Enter SSID here
station_cfg.pwd="password"  -- Enter password here


wifi.setmode(wifi.STATION)  -- set wi-fi mode to station
wifi.sta.config(station_cfg)-- set ssid & pwd to config
wifi.sta.connect()          -- connect to router

LEDpin = 2      -- declare LED pin
gpio.mode(LEDpin, gpio.OUTPUT)
server = net.createServer(net.TCP, 120)-- create TCP server

function receiver(sck, data)    -- process callback on recive data from client
  if string.find(data, "LED ON")  then
    sck:send("\r\nLED ON")
    gpio.write(LEDpin, gpio.HIGH)
  elseif string.find(data, "LED OFF")  then
    sck:send("\r\nLED OFF")
    gpio.write(LEDpin, gpio.LOW)
  elseif string.find(data, "EXIT")  then
    sck:close()
  else
    sck:send("\r\nCommand Not Found...!!!")
  end
end

if server then
  server:listen(80, function(conn)-- listen to the port 80
    conn:on("receive", receiver)
    conn:send("Hello Client\r\n")
    conn:send("1. Send 'LED ON' command to ON LED\r\n")
    conn:send("2. Send 'LED OFF' command to OFF LED\r\n")
    conn:send("3. Send 'EXIT' command to Exit\r\n")
  end)
end
