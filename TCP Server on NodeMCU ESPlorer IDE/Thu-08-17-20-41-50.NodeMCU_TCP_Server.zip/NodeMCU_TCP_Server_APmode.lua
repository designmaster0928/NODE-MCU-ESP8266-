wifi.setmode(wifi.SOFTAP)   -- set AP parameter
config = {}
config.ssid = "NodeMCU"
config.pwd = "12345678"
wifi.ap.config(config)

config_ip = {}  -- set IP,netmask, gateway
config_ip.ip = "192.168.2.1"
config_ip.netmask = "255.255.255.0"
config_ip.gateway = "192.168.2.1"
wifi.ap.setip(config_ip)


LEDpin = 2      -- declare LED pin
gpio.mode(LEDpin, gpio.OUTPUT)
server = net.createServer(net.TCP, 120)-- create TCP server

function receiver(sck, data)    -- process callback on recive data from client
  if string.find(data, "LED ON")  then
    sck:send("\r\nLED ON")
    gpio.write(LEDpin, gpio.HIGH)
  elseif string.find(data, "LED OFF")  then
    sck:send("\r\nLED OFF")
    gpio.write(LEDpin, gpio.LOW)
  elseif string.find(data, "EXIT")  then
    sck:close()
  else
    sck:send("\r\nCommand Not Found...!!!")
  end
end

if server then
  server:listen(80, function(conn)-- listen to the port 80
    conn:on("receive", receiver)
    conn:send("Hello Client\r\n")
    conn:send("1. Send 'LED ON' command to ON LED\r\n")
    conn:send("2. Send 'LED OFF' command to OFF LED\r\n")
    conn:send("3. Send 'EXIT' command to Exit\r\n")
  end)
end
