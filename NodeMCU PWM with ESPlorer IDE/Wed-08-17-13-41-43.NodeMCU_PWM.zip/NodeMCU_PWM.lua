LEDpin = 6          -- Declare LED pin no.
LEDbrightness = 0   -- Set initial LED brightness
PWMfrequency = 1000 -- Set PWM frequency
PWMDutyCycle = 512  -- Set PWM duty cycle in between 0-1023

pwm.setup(LEDpin, PWMfrequency, PWMDutyCycle)-- Setup PWM
pwm.start(LEDpin)   -- Start PWM on LED pin

while(1)
do
    LEDbrightness = adc.read(0) -- Read pot using ADC for LED brightness
    if LEDbrightness > 1023 then-- Limit LED brightness to max of duty cycle
        LEDbrightness = 1023
    end
    pwm.setduty(LEDpin, LEDbrightness)-- set PWM duty cycle to LED brightness
    print('LED Brightness:',math.floor(100*LEDbrightness/1023))-- print LED brightness
    tmr.delay(100000)   -- timer delay of 100000 us
end
