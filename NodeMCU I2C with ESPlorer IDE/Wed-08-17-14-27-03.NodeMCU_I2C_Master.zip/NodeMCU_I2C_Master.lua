id  = 0 -- always 0
sda = 1 -- set pin 1 as sda
scl = 2 -- set pin 2 as scl

i2c.setup(id, sda, scl, i2c.SLOW)-- initialize i2c

i2c.start(id)   -- send start condition
if (i2c.address(id, 8, i2c.TRANSMITTER))-- set slave address and transmit direction
then
    i2c.write(id, 'Hello Arduino')  -- write string to slave arduino
    i2c.stop(id)    -- send stop condition
    i2c.start(id)   -- send start condition
    i2c.address(id, 8, i2c.RECEIVER)-- set slave address and receive direction
    response = i2c.read(id, 13) -- read defined length response from slave
    i2c.stop(id)    -- send stop condition
    print('Arduino responds with:',response) -- print response received from slave
else
    print('Arduino Not responding..!')
end