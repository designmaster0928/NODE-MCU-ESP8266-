GPIO_PIN = 2

gpio.mode(GPIO_PIN,gpio.INT)    -- Set GPIO interrupt mode for pin 

function interrupt(level, stamp)-- callback function while interrupt
    gpio.trig(GPIO_PIN)         -- disable interrupt for that pin
    tmr.delay(700000)           -- wait 700 ms
    print('level:',level)       -- print level of on pin
    print('stamp(us):',stamp)   -- print timestamp while interrupt occur
    print('interrupt on pin:', GPIO_PIN)--print interrupt pin no.
    gpio.trig(GPIO_PIN,"up", interrupt)--re-enable interrupt on pin while exit
end

gpio.trig(GPIO_PIN,"up", interrupt)-- set interrupt type up i.e. rising edge
