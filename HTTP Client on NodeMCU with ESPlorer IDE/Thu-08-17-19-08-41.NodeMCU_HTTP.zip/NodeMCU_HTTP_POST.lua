station_cfg={}
station_cfg.ssid="ssid"  -- Enter SSID here
station_cfg.pwd="password"  -- Enter password here
server = "http://api.thingspeak.com/update" -- set server URL
count = 0   -- set initiale count to 0


wifi.setmode(wifi.STATION)  -- set wi-fi mode to station
wifi.sta.config(station_cfg)-- set ssid & pwd to config
wifi.sta.connect()          -- connect to router

function PostToThingSpeak()-- callback function for post data
string = "api_key=1EYZIS5OCRJSKZHG&field1="..count
http.post(server,'', string,
  function(code, data)
    if (code < 0) then
      print("HTTP request failed")
    else
      print(code, data)
      count = count+1   -- increment count after each successfull post
    end
  end)
end
-- call post function after each 20 second for thingspeak server update
tmr.alarm(1, 20000, 1, function() PostToThingSpeak() end)
  