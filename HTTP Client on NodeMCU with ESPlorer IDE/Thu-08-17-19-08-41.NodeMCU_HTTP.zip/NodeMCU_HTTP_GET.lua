station_cfg={}
station_cfg.ssid="ssid"  -- Enter SSID here
station_cfg.pwd="password"  -- Enter password here
server = "http://api.thingspeak.com/channels/309236/feeds/last.txt" -- set server URL


wifi.setmode(wifi.STATION)  -- set wi-fi mode to station
wifi.sta.config(station_cfg)-- set ssid & pwd to config
wifi.sta.connect()          -- connect to router

function GetFromThingSpeak()-- callback function for get data
http.get(server,'',
  function(code, data)
    if (code < 0) then
      print("HTTP request failed")
    else
      print(code, data)
    end
  end)
end
-- call get function after each 10 second
tmr.alarm(1, 10000, 1, function() GetFromThingSpeak() end)
  